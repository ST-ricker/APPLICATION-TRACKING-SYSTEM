from flask import Flask, render_template, request, session, abort
import csv
import socket


from os import urandom

app = Flask(__name__)
app.secret_key = urandom(24)

@app.route('/',methods=['GET'])
def home():
    session['attempt'] = 100
    # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    return render_template('index.html')

@app.route('/admin-login' ,methods=["get","post"])
def admin_login():
     return render_template("admin-login.html")

@app.route('/login_admin' ,methods=["post","get"])
def login1():
    while session['attempt'] > 0:
        if request.method == "POST":
            username = request.form["username"]
            password = request.form["password"]
            with open('login_Database.csv', mode='r') as f:
                reader = csv.reader(f, delimiter=',')
                for row in reader:
                    if row == [username, password]:
                        session['login'] = username
                        return render_template("final_3.html")
                    else:
                        attempt = session.get('attempt')
                        attempt -= 1
                        session['attempt'] = attempt
                        msg = "Invalid Credentials Entered " \
                              " Attempts Remaining:"
                        attempt = attempt
                        return render_template("admin-login.html", msg=msg, attempt=attempt)
        else:
            abort(404, "Get method is not allowed in this page, Navigate using post requests")
    else:
        abort(404, "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")


@app.route('/recruiter-login' ,methods=["get","post"])
def recruiter_login():
    return render_template('recruiter-login.html')



@app.route('/login_recruiter', methods=["post","get"])
def login2():
    while session['attempt'] > 0:
        if request.method == "POST":
            username = request.form["username"]
            password = request.form["password"]
            with open('login_Database.csv', mode='r') as f:
                reader = csv.reader(f, delimiter=',')
                for row in reader:
                    if row == [username, password]:
                        session['login'] = username
                        return render_template("final_1.html")
                    else:
                        attempt = session.get('attempt')
                        attempt -= 1
                        session['attempt'] = attempt
                        msg = "Invalid Credentials Entered " \
                              " Attempts Remaining:"
                        attempt = attempt
                        return render_template("recruiter-login.html", msg=msg,attempt=attempt )
        else:
            abort(404, "Get method is not allowed in this page, Navigate using post requests")
    else:
        abort(404, "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")


@app.route('/interviewer-login' ,methods=["post","get"])
def interviewer_login():
    return render_template("interviewer-login.html")


@app.route("/login_interviewer" ,methods=["POST","GET"])
def login3():
    while session['attempt'] > 0:
        if request.method == "POST":
            username = request.form["username"]
            password = request.form["password"]
            with open('login_Database.csv', mode='r') as f:
                reader = csv.reader(f, delimiter=',')
                for row in reader:
                    if row == [username, password]:
                        session['login'] = username
                        return render_template("final_2.html")
                    else:
                        attempt = session.get('attempt')
                        attempt -= 1
                        session['attempt'] = attempt
                        msg = "Invalid Credentials Entered " \
                              " Attempts Remaining:"
                        attempt = attempt
                        return render_template("interviewer-login.html" ,msg=msg,attempt=attempt)


        else:
            abort(404, "Get method is not allowed in this page, Navigate using post requests")

    else:
        abort(404, "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")


@app.route('/logout',methods=["post"])
def logout():
    session.pop()
    return render_template("/")

if __name__ == '__main__':
    # RUN
    app.run(port=500, debug=True)



    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)
    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)







    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)


    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)
    # from flask import Flask, render_template, request, session, abort
    # import csv
    # import socket
    #
    # from os import urandom
    #
    # app = Flask(__name__)
    # app.secret_key = urandom(24)
    #
    #
    # @app.route('/', methods=['GET'])
    # def home():
    #     session['attempt'] = 3
    #     # https: // stackoverflow.com / questions / 38825111 / counting - login - attempts - in -flask
    #     return render_template('index.html')
    #
    #
    # @app.route('/admin-login', methods=["get", "post"])
    # def admin_login():
    #     return render_template("admin-login.html")
    #
    #
    # @app.route('/login_admin', methods=["post", "get"])
    # def login1():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_3.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("admin-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/recruiter-login', methods=["get", "post"])
    # def recruiter_login():
    #     return render_template('recruiter-login.html')
    #
    #
    # @app.route('/login_recruiter', methods=["post", "get"])
    # def login2():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_1.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("recruiter-login.html", msg=msg, attempt=attempt)
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # @app.route('/interviewer-login', methods=["post", "get"])
    # def interviewer_login():
    #     return render_template("interviewer-login.html")
    #
    #
    # @app.route("/login_interviewer", methods=["POST", "GET"])
    # def login3():
    #     while session['attempt'] > 0:
    #         if request.method == "POST":
    #             username = request.form["username"]
    #             password = request.form["password"]
    #             with open('login_Database.csv', mode='r') as f:
    #                 reader = csv.reader(f, delimiter=',')
    #                 for row in reader:
    #                     if row == [username, password]:
    #                         session['login'] = username
    #                         return render_template("final_2.html")
    #                     else:
    #                         attempt = session.get('attempt')
    #                         attempt -= 1
    #                         session['attempt'] = attempt
    #                         msg = "Invalid Credentials Entered " \
    #                               " Attempts Remaining:"
    #                         attempt = attempt
    #                         return render_template("interviewer-login.html", msg=msg, attempt=attempt)
    #
    #
    #         else:
    #             abort(404, "Get method is not allowed in this page, Navigate using post requests")
    #
    #     else:
    #         abort(404,
    #               "MAXIMUM ATTEMPT LIMIT REACHED, WE ARE BLOCKING YOUR ACCESS TO THE WEBSITE CONTACT ADMINISTRATOR FOR MORE DETAILS")
    #
    #
    # if __name__ == '__main__':
    #     # RUN
    #     app.run(port=500, debug=True)
